(function($){
  $(document).ready(function(){
    // Init Color Pickers
    if( $('.my-color-field').length ) {
        $('.my-color-field').wpColorPicker();
    }

    // Media Uploader
    function openMedia(fieldSelector) {
      var frame = wp.media({
        title: cleanliteUcAdmin.selectImage || 'Select Image',
        button: { text: 'Use this image' },
        multiple: false
      });
      frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        $(fieldSelector).val( attachment.url );
      });
      frame.open();
    }

    $('#cleanlite_uc_logo_button').on('click', function(e){
      e.preventDefault();
      openMedia('#cleanlite_uc_logo');
    });

    $('#cleanlite_uc_bg_button').on('click', function(e){
      e.preventDefault();
      openMedia('#cleanlite_uc_bg');
    });
  });
})(jQuery);