<?php
/**
 * Plugin Name: CleanLite Under Construction & Countdown
 * Plugin URI:  https://adilrafeeque.com/under-construction-countdown
 * Description: Show a branded under construction page with a countdown timer, custom colors, and fonts. Optimized for CleanLite but works with any theme.
 * Version:     1.2.1
 * Author:      adilrafeeque
 * Author URI:  https://adilrafeeque.com
 * License:     GPLv2 or later
 * Text Domain: cleanlite-under-construction-countdown
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'CLEANLITE_UC_VERSION' ) ) {
    define( 'CLEANLITE_UC_VERSION', '1.2.1' );
}

if ( ! defined( 'CLEANLITE_UC_DIR' ) ) {
    define( 'CLEANLITE_UC_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'CLEANLITE_UC_URL' ) ) {
    define( 'CLEANLITE_UC_URL', plugin_dir_url( __FILE__ ) );
}

require_once CLEANLITE_UC_DIR . 'includes/admin.php';
require_once CLEANLITE_UC_DIR . 'includes/frontend.php';

