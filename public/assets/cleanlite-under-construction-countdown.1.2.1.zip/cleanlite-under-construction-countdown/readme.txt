=== CleanLite Under Construction & Countdown ===
Contributors: adilrafeeque
Donate link: https://adilrafeeque.com/contact
Tags: maintenance, coming soon, countdown, construction, under construction
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A branded under construction page with a countdown timer, custom colors, and fonts. Optimized for CleanLite but works with any theme.

== Description ==

CleanLite Under Construction & Countdown is a lightweight plugin that shows a professional maintenance page to visitors while you work on your site.

Logged-in users (administrators and editors) see the full site normally, allowing you to work on content and design, while visitors see a clean, branded "coming soon" page.

**Main Features:**
* **Fully Customizable:** Change fonts, colors (heading, text, timer, overlay), and timer styles.
* **Mobile Responsive:** Optimized layout looks great on all devices.
* **Branded:** Upload your own Logo and Background image.
* **Countdown:** Specialized Date & Time picker to show exactly when you launch.
* **Social Icons:** Easily link to your Facebook, X (Twitter), and Instagram.
* **SEO Friendly:** Sends proper 503 Service Unavailable headers to search engines.
* **Lightweight:** Minimal code, no heavy frameworks.

== Frequently Asked Questions ==

= How do I enable the maintenance page? =
Go to Settings > CleanLite Under Construction and check "Activate maintenance page".

= Who can see the website when this is active? =
Logged-in administrators and editors can see the website normally. Logged-out visitors will see the maintenance page.

= How do I set the countdown? =
In the settings, check "Show countdown" and use the date picker to select your launch date and time.

== Screenshots ==
1. Admin Settings - New customization options.
2. Frontend View - Clean maintenance page with countdown.

== Changelog ==

= 1.2.1 =
* Improved mobile layout (timer alignment).
* Fixed CSS caching issues.

= 1.1.0 =
* Added color pickers, font selection, and custom labels.

= 1.0.0 =
* Initial release.